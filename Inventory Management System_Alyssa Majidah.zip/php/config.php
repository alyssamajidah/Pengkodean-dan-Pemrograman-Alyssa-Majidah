<?php
header('Content-Type: application/json');

$host = 'localhost';
$username = 'root'; // Ganti dengan password MySQL Anda
$password = ''; // Ganti dengan password MySQL Anda
$database = 'inventory_db';

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Database connection failed']));
}
?>