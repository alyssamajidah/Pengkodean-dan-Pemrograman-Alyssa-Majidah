<?php
require_once 'config.php';

$id = $_GET['id'] ?? 0;

$stmt = $conn->prepare("DELETE FROM items WHERE id = ?");
$stmt->bind_param("i", $id);
$success = $stmt->execute();

echo json_encode(['success' => $success]);

$conn->close();
?>