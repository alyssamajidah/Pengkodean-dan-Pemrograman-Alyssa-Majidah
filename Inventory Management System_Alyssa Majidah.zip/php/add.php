<?php
require_once 'config.php';

$data = json_decode(file_get_contents('php://input'), true);

$stmt = $conn->prepare("INSERT INTO items (name, quantity, price) VALUES (?, ?, ?)");
$stmt->bind_param("sid", $data['name'], $data['quantity'], $data['price']);
$success = $stmt->execute();

echo json_encode(['success' => $success]);

$conn->close();
?>