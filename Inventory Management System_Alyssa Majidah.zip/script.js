document.addEventListener('DOMContentLoaded', () => {
    loadItems();

    document.getElementById('inventoryForm').addEventListener('submit', (e) => {
        e.preventDefault();
        
        const item = {
            name: document.getElementById('itemName').value,
            quantity: document.getElementById('quantity').value,
            price: document.getElementById('price').value
        };

        fetch('php/add.php', {  // Ubah ke add.php
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(item)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                loadItems();
                document.getElementById('inventoryForm').reset();
            }
        });
    });
});

function loadItems() {
    fetch('php/get.php')  // Ubah ke get.php
        .then(response => response.json())
        .then(data => {
            const tbody = document.querySelector('#inventoryTable tbody');
            tbody.innerHTML = '';
            
            data.forEach(item => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td>${item.id}</td>
                    <td>${item.name}</td>
                    <td>${item.quantity}</td>
                    <td>Rp ${item.price}</td>
                    <td><button class="delete-btn" onclick="deleteItem(${item.id})">Hapus</button></td>
                `;
                tbody.appendChild(tr);
            });
        });
}

function deleteItem(id) {
    fetch(`php/delete.php?id=${id}`, {  // Ubah ke delete.php
        method: 'POST'
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            loadItems();
        }
    });
}